from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Account
from django.contrib.auth.models import Group


admin.site.unregister(Group)


class AccountAdmin(UserAdmin):
    list_display = (
        "email",
        "username",
        "date_joined",
        "last_login",
        "from_pce",
        "is_admin",
        "is_staff",
        "is_faculty",
    )
    search_fields = (
        "email",
        "username",
    )
    readonly_fields = ("date_joined", "last_login")

    filter_horizontal = ()
    list_filter = ()
    fieldsets = ()


admin.site.register(Account, AccountAdmin)
