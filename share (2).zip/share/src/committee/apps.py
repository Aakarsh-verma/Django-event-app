from django.apps import AppConfig


class CommitteeConfig(AppConfig):
    name = 'committee'
